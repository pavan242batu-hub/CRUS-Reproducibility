# Reviewer guide

## 1. Purpose and status

This package provides implementation notebooks, saved configurations,
split identifiers, case-level outputs, and supporting analysis artifacts.

It is not yet a verified clean-environment, end-to-end inference release.
The verification scope and limitations are stated below.

## 2. Start here: regenerate metrics from saved predictions

From the repository root, run:

python scripts/regenerate_primary_metrics.py --package-root .
python scripts/verify_matched_rankings.py --package-root .

These scripts do not run model inference or require raw dialogue inputs.

Outputs are written to regenerated/.

See REPRODUCING_RESULTS.md for metric definitions and verification scope.

## 3. Verified results

- The primary metric script regenerated full-coverage classification
  and native-acceptance metrics and checked saved correctness flags.
- The matched-ranking script reconstructed all 45 method/target rows
  from saved ranking scores.
- Eleven count/metric fields agreed with the saved verified summary.
- Integer counts matched exactly.
- Floating-point comparisons used absolute tolerance 1e-10.

These checks do not establish reproduction of every manuscript result.

## 4. Implementation notebooks

notebooks/CRUS_R1_5_External_Transfer.ipynb
notebooks/revised_risk_aware_hybrid_pipeline_v2.ipynb

These are output-cleared historical implementation notebooks.
They retain original path references and multiple revision analyses.
Do not execute all cells indiscriminately.

A tested section-by-section execution map for fresh model inference
has not yet been supplied.

## 5. Configurations and split identifiers

Primary configuration and policies:
artifacts/corrected_experiment_outputs/final_pretest_protocol.json
artifacts/corrected_experiment_outputs/validation_selected_policies.json

Primary split:
artifacts/data_audit/constrained_split_manifest.csv

Repeated splits:
artifacts/supplementary_repeated_splits/seed_*/split_manifest.csv

Calibration-fold assignments are provided separately.

Use supplied split assignments when reproducing reported analyses;
do not generate new splits as substitutes.

## 6. Data access and reconstruction

Raw input dialogue files are not included in this package selection.

Before claiming end-to-end reproducibility, the authors must document:
- Original dataset access location and version.
- Source CSV filenames and source-row indexing convention.
- Record-ID construction.
- Text normalization, cleaning, and filtering.
- Group construction and duplicate handling.
- Reconstruction of selected additional-MTS records.
- Perturbation generation and seeds.

Do not guess source-row indexing or substitute a different dataset version.

## 7. Text-excluded derivatives

Files ending __text_excluded.csv omit the columns listed in:
manifest/additional_artifact_export_log.json

Their filenames and checksums differ from the original artifacts.
Historical metadata can still refer to original-file checksums.

The query-text file inference_inputs.csv is not distributed here.

## 8. Additional analyses

Additional-analysis artifacts are included as supporting outputs.
Their presence does not mean all metrics were independently regenerated.

See ADDITIONAL_ARTIFACTS.md and the export logs.

The additional-MTS analysis must not automatically be interpreted as
independent cross-dataset validation. Consult its saved scope and
limitation fields.

## 9. MedCPT baseline

See MEDCPT_ARTIFACTS.md.

Primary and repeated-run configurations, predictions, selections,
and summaries are provided. Training embeddings are excluded.

MedCPT metrics have not been independently regenerated in this
packaging workflow.

## 10. Environment records

See environment/.

Recorded versions are partial historical snapshots, not a complete,
tested dependency lockfile.

Six recorded package versions match between the primary run and
each repeated run. pandas and scipy versions are not recorded in
the repeated-run retrieval metadata.

Do not infer the main-run environment from a separate baseline.

## 11. Integrity and provenance

See manifest/ for inventories, transformation logs, and checksums.

Checksums identify files; they do not establish scientific validity,
privacy compliance, or execution success.

## 12. Outstanding release tasks

- Complete manual sharing and redistribution review.
- Complete dataset-access/reconstruction instructions.
- Document fresh-inference execution order and dependencies.
- Map final manuscript tables/figures to artifacts and commands.
- Refresh final inventories/checksums after all edits.
- Arrange and test editor/reviewer access.

# Reproduction from saved predictions

Run commands from the repository root.

## Required analysis packages

These scripts use Python, NumPy, pandas, and scikit-learn.
The primary saved protocol records:
- numpy: 2.1.3
- pandas: 2.2.3
- scikit-learn: 1.6.1

The current packaging session successfully ran the scripts.
A clean-environment installation test has not yet been completed.

## Commands

python scripts/regenerate_primary_metrics.py --package-root .
python scripts/verify_matched_rankings.py --package-root .

## Outputs

The regenerated/ directory contains:
- primary_full_coverage_metrics.csv
- primary_native_acceptance_metrics.csv
- primary_matched_count_metrics.csv
- matched_rankings_all_targets.csv
- matched_rankings_agreement_report.csv

## Verified scope

The matched-ranking script reconstructs selections from saved
ranking scores, sorting by ranking_score descending and record_id
ascending for ties.

It regenerated 45 method/target rows at accepted-case targets
113, 115, 117, 118, and 171.

Eleven count/metric fields agreed with the saved verified summary.
Integer counts matched exactly. Floating-point fields were checked
with absolute tolerance 1e-10 and relative tolerance zero.

The primary regeneration script also checked saved correctness flags
against labels and predictions and reconstructed full-coverage and
native-acceptance metrics.

## Not yet verified

- Automated agreement of all full-coverage/native metrics with summaries.
- Calibration metrics.
- Saved boundary-tie diagnostic fields.
- All manuscript figures.
- All repeated-run metrics.
- Additional revision experiments.
- End-to-end model inference in a clean environment.

## Policy distinction

Native CRUS gating and ranking-based top-k acceptance are different
selection rules. Equal accepted-case counts do not imply identical
selected records.

## Environment provenance

The primary protocol records eight package versions.
Six recorded versions match in each repeated-run metadata file.
The repeated-run metadata do not record pandas or scipy versions.
These are partial environment records, not a complete lockfile.
